<?php

/*mysql_connect("localhost","root","");
mysql_select_db("pos");
//$ettrtf="localhost,root,,gocommerce";
*/


mysql_connect("localhost","gopos","Goedang$888");
mysql_select_db("pos");
//$ettrtf="localhost,root,,gopos";




/*
mysql_connect("localhost","root","");
mysql_select_db("test2");
$ettrtf="localhost,root,,test2";
*/
?>