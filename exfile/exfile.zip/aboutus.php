<?php
include 'layout/header.php';
?>
	<!-- page -->
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="index.php">Home</a>
						<i>|</i>
					</li>
					<li>About Us</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //page -->
	<!-- Terms of use-section -->
	<section class="terms-of-use">
		<!-- terms -->
		<div class="terms">
			<div class="container">
				<!-- tittle heading -->
				<h3 class="tittle-w3l">About Us
					
				</h3>
				<!-- //tittle heading -->
				<p><b>Goedang Oleh Oleh</b> adalah tempat yang menyediakan berbagai macam oleh-oleh khas Indonesia terutama Malang. Kami bertempat di Jl. Simpang Tenaga II no 12 Malang yang memiliki lokasi strategis. 
				Sebagai Pusat Jajanan Serba Ada disini menyediakan Ruang Retail sebagai toko Oleh-Oleh. 
				</p>
				<p>Kami menyediakan banyak jajanan khas Malang dan Jawa Timur.</p>
				 
				 
				<p>Kenapa Anda Memilih Kami ???</p>

				<h6>PARKIR LUAS</h6>
				<p>Goedang Oleh Oleh memiliki area parkir yang luas dan aman.
				Mampu menampung banyak kendaraan mulai dari kendaraan pribadi maupun umum.
				<br><br>
				Dengan lokasi Goedang Oleh Oleh yang strategis berada di depan jalan raya.
				</p>

				<h6>MUSHOLA</h6>

				<p>Goedang Oleh Oleh juga menyediakan Mushola untuk tempat beribadah, dengan ruangan yang bersih dan nyaman untuk digunakan.
				</p>

				<h6>REST AREA</h6>

				<p>Goedang Oleh Oleh juga memberikan fasilitas tempat beristirahat yang dapat dinikmati oleh semua pengunjung.</p>
			</div>
		</div>
		<!-- /terms -->
	</section>
	<!-- //Terms of use-section -->


<?php
include('layout/footer.php');
?>