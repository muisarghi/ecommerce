<?php
include 'layout/header.php';
?>
	<!-- page -->
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="index.php">Home</a>
						<i>|</i>
					</li>
					<li>How To Shop</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //page -->
	<!-- Terms of use-section -->
	<section class="terms-of-use">
		<!-- terms -->
		<div class="terms">
			<div class="container">
				<!-- tittle heading -->
				<h3 class="tittle-w3l">How To Shop
					
				</h3>
				<!-- //tittle heading -->
				<p align="center"><b>6 Langkah mudah cara berbelanja di toko online kami:</b></p>
				<p align="center">
				Pilih Barang<br>
				Check Out<br>
				Transfer pembayaran<br>
				Konfirmasi Pembayaran<br>
				Barang dikirim.<br>
				Selesai
				</p>
				<br><br>
				<p align="center"><b><u>Mohon Diperhatikan :</u></b></p>
				
				<p align="center">
				Harga dapat berubah sewaktu-waktu<br>
				Total harga yang tertera belum termasuk ongkos kirim<br>
				Barang akan kami transaksikan setelah pembayaran masuk dalam rekening kami<br>
				Semua barang yang kami kirimkan dalam keadaan baik dan utuh<br>
				Bila ada kerusakan maupun keterlambatan penerimaan barang bukan merupakan tanggung jawab kami
				</p>

			</div>
		</div>
		<!-- /terms -->
	</section>
	<!-- //Terms of use-section -->


<?php
include('layout/footer.php');
?>