<ul>
	<li>
	<?php
	echo"<a href='index.php?load=home'><span class='span'>Home</span></a>
	";?>
	</li>

	<li>
	<?php
	echo"<a href='index.php?load=content'><span class='span'>Content</span></a>
	";?>
	</li>

	<!--s
	<li class="menu-item-has-children dropdown">
	<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	<span class="span">Content</span>
	</a>
	<ul class="sub-menu children dropdown-menu">
	<li><a href="ui-buttons.html">Buttons</a></li>
	-->
</ul>
</li>
</ul>