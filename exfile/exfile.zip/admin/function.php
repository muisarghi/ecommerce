<?php
ob_start();




class go
{
	function home()
		{
		echo"HALAMAN ADMINISTRATOR <br><br><br><br><br><br><br>";	
		}
	
	function content()
		{
		echo"<h3 align='center'>Daftar Content</h3>
		<br>
		<p align='center'>
		<a href='index.php?load=newcontent'><i class='fa fa-file-o'></i><br>New</a>
		<br>
		<table width='100%' border='0'>
		<tr>
		<td align='center'>No</td>
		<td align='center'>Judul</td>
		<td align='center'>Tanggal</td>
		<td align='center'>Update</td>
		<td align='center'>Act</td>
		</tr>
		</table>
		";
		}
	
	function newcontent()
	{
	echo"<h3 align='center'>CONTENT BARU</h3>
	<br>
	<form action='index.php?load=contentin' method='post'>
	<table width='100%'>
	<tr>
	<td width='20%'>Judul</td>
	<td><input type='text' name='judul' size='40'></td>
	</tr>

	<tr>
	<td>Isi</td>
	<td> </td>
	</tr>
	</table>
	</form>
	";
	}
}

?>