<?php
ob_start();
include('function.php');

$load=$_GET['load'];
$datenow=date('Y-m-d');

	switch($load)
	{
	case 'home':
	go::home($option);
	break;
	case 'content':
	go::content($option);
	break;
	case 'newcontent':
	go::newcontent($option);
	break;
	default:
	go::home($option);
	break;
	}	

?>