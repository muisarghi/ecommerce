<?php include 'header.php'; ?>

	<!-- page -->
	<div class="services-breadcrumb">
		<div class="agile_inner_breadcrumb">
			<div class="container">
				<ul class="w3_short">
					<li>
						<a href="index.php">Home</a>
						<i>|</i>
					</li>
					<li>Login Administrator</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- //page -->
	<!-- contact page -->
	<div class="contact-w3l">
		<div class="container">
			<!-- tittle heading -->
			<h3 class="tittle-w3l">Login
				<span class="heading-style">
					
				</span>
			</h3>
			<!-- //tittle heading -->
			<!-- contact -->
			<div class="contact agileits">
				<div class="contact-agileinfo">
					<div class="contact-form wthree">
						<form action="login.php" method="post">
							
								<div class="col-md-2">
								Username
								</div>
								<div class="col-md-10">
									<input type="text" name="user" placeholder="Name" required="">
								</div>

								<div class="col-md-2">
								Password
								</div>
								<div class="col-md-10">
									<input type="password" name="password" placeholder="Password" required="">
								</div>

								
									
							<input type="submit" value="Submit">
							
						</form>
					</div>
					
				</div>
			</div>
			<!-- //contact -->
		</div>
	</div>
	<!-- map -->
	
	<?php include 'footer.php'; ?>